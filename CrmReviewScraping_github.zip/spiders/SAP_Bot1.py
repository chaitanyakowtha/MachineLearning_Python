import scrapy


class SAP_Bot1(scrapy.Spider):
	name = 'SAP_Bot1'
	allowed_domains = ['www.capterra.com/']
	start_urls = ['https://www.capterra.com/p/77372/SAP-CRM/#reviews',
			'https://www.capterra.com/gdm_reviews?page=1&product_id=77372']

	def parse(self, response):
	#Extracting the content using xpath selectors
		divs = response.xpath('//div[@class="cell eleven-twelfths  palm-one-whole"]')
		for div in divs:
			Main_comment = div.xpath('.//h3[@class = "delta  weight-bold  half-margin-bottom"]/q/text()').extract()
			Reviewed_On = div.xpath('.//div[@class = "quarter-margin-bottom  micro  color-gray  weight-normal  text-right  palm-text-left"]//text()').extract()
			Reviewer_name = div.xpath('.//div[@class = "epsilon  weight-bold  inline-block"]/text()').extract()
			Reviewer_Role = div.xpath('.//div[@class = "opacity-threequarters"]/text()').extract()
			Reviewer_Department_company = div.xpath('.//div[@class = "italic  opacity-threequarters"]/text()').extract()
			Review_Comments = div.xpath('.//p/text()').extract()
			scraped_info = {'Main_comment':Main_comment,'Reviewed_On':Reviewed_On,'Reviewer_name':Reviewer_name,'Reviewer_Role':Reviewer_Role,'Reviewer_Department_company':Reviewer_Department_company,'Review_Comments':Review_Comments}
			yield scraped_info


